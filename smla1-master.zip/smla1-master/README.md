# Statistical Machine Learning 
## Assignment  1

Requirements `python3, sklearn, numpy`

Run `python3 data/python_dict.py` to preprocess the graph and pickle it.
Then run `python3 main.py dev` to test the current sampling and classification pipeline.
